#include "block_allocator.h"

namespace dynamic{
	block_allocator block_allocator::global;
};