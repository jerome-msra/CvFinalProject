#include "fixed_point.h"

namespace exttype{

	/*
	unsigned int scale2int(const float & x){
		return (unsigned int)(x*(1<<16));
	};

	float & shr(float & x,const int & n){
		return x/=(1<<n);
	};

	float & shl(float & x,const int & n){
		return x*=(1<<n);
	};
	*/
};