#include "stdafx.h"
#include "r3grid.h"

namespace _geom{
	namespace R3{
	};
};

