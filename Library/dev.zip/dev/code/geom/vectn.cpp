#include "vectn.h"

namespace geom{
	
};
