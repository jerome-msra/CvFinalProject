#include "hvect.h"

namespace geom{
	namespace homography{
		void test(){
			hvect2 h2 = vectn<2>();
		};
	};
};