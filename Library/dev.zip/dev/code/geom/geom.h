#ifndef geom_geom_h
#define geom_geom_h

#include "math.h"
#include "vectn.h"

namespace geom{


};

#endif