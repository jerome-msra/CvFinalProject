#include "math.h"

namespace geom{
	const double eps0=1.0E-7;
	const double pi=3.14159265358979323846;
};
