function nE = get_nE(energy)
	nE = get(energy.G,'m');
end