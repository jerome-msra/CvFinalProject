function C = operator_func(E,x)

C = cost(E,x);

end