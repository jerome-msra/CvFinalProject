function L = get_poly(energy)
	L = energy.L;
end