function nV = get_nV(energy)
	nV = get(energy.G,'n');
end