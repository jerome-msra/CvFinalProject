function nV = get_nV(G)
% get_nV(G) return number of vertices
%
nV = length(G.V);
end