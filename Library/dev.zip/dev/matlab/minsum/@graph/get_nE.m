function nE = get_nE(G)
% get_nE(G) return number of edges
%
nE = size(G.E,2);
end