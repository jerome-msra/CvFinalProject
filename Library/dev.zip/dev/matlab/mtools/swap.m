function [B A] = swap(A,B)
end