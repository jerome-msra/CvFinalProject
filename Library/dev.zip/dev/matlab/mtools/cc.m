clear all;
close all;
clc;
clear classes;