maddpath('.');
maddpath('img');