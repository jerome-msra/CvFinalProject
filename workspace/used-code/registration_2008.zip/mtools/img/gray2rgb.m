function I = gray2rgb(U)
I = U;
I(:,:,2)=U;
I(:,:,3)=U;
end