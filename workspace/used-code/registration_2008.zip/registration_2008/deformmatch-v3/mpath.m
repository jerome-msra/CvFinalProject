run ../../mtools/mpath.m
maddpath('.');
maddpath('mex');
maddpath('data_functions');
maddpath('my_aux');