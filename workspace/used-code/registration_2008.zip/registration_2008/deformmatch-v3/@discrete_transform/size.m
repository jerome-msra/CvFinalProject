function sz = size(f)
% sz = size(f) -- returns size of the discrete_transform
%
sz = msize(f.f,[1 2]);

end