function q = my_fun(c1,c2)

q = sum(c1.*c2,3);

end