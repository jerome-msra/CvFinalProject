function K = get_K(energy)
	K = energy.K;
end