function A = kron3(a1, a2, a3)

A = kron(a1,kron(a2,a3));

end